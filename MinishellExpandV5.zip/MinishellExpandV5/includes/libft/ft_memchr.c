/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:07:37 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:07:37 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *str, int c, size_t n)
{
	size_t	i;
	char	*s;

	s = (char *)str;
	i = 0;
	while (i < n)
	{
		if ((unsigned char)s[i] == (unsigned char)c)
			return ((char *)str + i);
		i++;
	}
	return (NULL);
}

/* #include <stdio.h>
int main ()
{
   const char str[] = "this .is some.thing here";
   const char ch = '.';
   char *res_ptr = ft_memchr(str, ch, 10);

   printf("String after %c is: %s\n", ch, res_ptr);
   
   return(0);
}  */