/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:08:01 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:08:01 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putchar_fd(char c, int fd)
{
	write(fd, &c, 1);
}

/* #include <fcntl.h>
int main()
{
    char *filename = "output.txt";
    char c = 'A';

    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);

    ft_putchar_fd(c, fd);

    close(fd);

    return 0;
} */