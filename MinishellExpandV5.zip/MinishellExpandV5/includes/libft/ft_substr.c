/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:10:54 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:10:54 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*sub;
	size_t	size;

	if (!s)
		return (NULL);
	size = ft_strlen(s);
	if (start >= size)
		return (ft_strdup(""));
	size = ft_strlen(s + start);
	if (size < len)
		len = size;
	sub = (char *)malloc(sizeof(char) * (len + 1));
	if (!sub)
		return (NULL);
	ft_strlcpy(sub, s + start, (len + 1));
	return (sub);
}

/*
#include <stdio.h>
int main()
{
    const char *str1 = "Hello, World!";
    unsigned int start1 = 7;
    size_t len1 = 5;
    char *substr1 = ft_substr(str1, start1, len1);
    printf("Test 1: Substring of '%s' from index %u with
     length %zu: '%s'\n", str1, start1, len1, substr1);
    free(substr1);

    const char *str2 = "Testing";
    unsigned int start2 = 10;
    size_t len2 = 3;
    char *substr2 = ft_substr(str2, start2, len2);
    printf("Test 2: Substring of '%s' from index %u with
     length %zu: '%s'\n", str2, start2, len2, substr2);
    free(substr2);

    const char *str3 = "12345";
    unsigned int start3 = 2;
    size_t len3 = 10;
    char *substr3 = ft_substr(str3, start3, len3);
    printf("Test 3: Substring of '%s' from index %u with
     length %zu: '%s'\n", str3, start3, len3, substr3);
    free(substr3);

    return 0;
}
*/