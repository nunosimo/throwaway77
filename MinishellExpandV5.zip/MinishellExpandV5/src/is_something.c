/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   is_something.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/30 12:09:06 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/07/30 12:16:34 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

int	is_quote(char c)
{
	return (c == '\'' || c == '"');
}

int	is_separator(char *str)
{
	return (*str == ' ' || *str == '\t' || *str == '|'
		|| *str == '>' || *str == '<');
}

int	ft_isspace(char c)
{
	if (c == '\t' || c == '\n' || c == '\v'
		|| c == '\f' || c == '\r' || c == ' ')
		return (1);
	return (0);
}

int	is_invalid_char(char c)
{
	return (c == '#' || c == '*' || c == '.' || c == '~' || c == '>'
		|| c == '\'' || c == ':' || c == ',' || c == '%' || c == '}'
		|| c == '@' || c == ' ' || c == ']' || c == '[' || c == '|'
		|| c == '=' || c == '<' || c == '!' || c == '?' || c == '^'
		|| c == '/' || c == '\"' || c == '&' || c == '+' || c == '{'
		|| c == '-');
}

int	if_digit(char *str, int i)
{
	return (str[i] == '$' && ft_isdigit(str[i + 1]));
}
