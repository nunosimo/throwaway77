/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expand_env_1.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/30 12:08:42 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/05 05:34:53 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

static void	handle_digit_or_quote(char **word, int *len, int *i, bool is_digit)
{
	int	k;

	if (is_digit)
		k = *i + 2;
	else
		k = *i + 1;
	if (is_digit && (k >= *len || (*word)[k] == '\0'))
	{
		(*word)[*i] = '\0';
		*len = *i;
	}
	else
	{
		while ((*word)[k] != '\0')
		{
			(*word)[*i] = (*word)[k];
			(*i)++;
			k++;
		}
		(*word)[*i] = '\0';
		*len = *i;
	}
	*i = -1;
}

static void	handle_expandable(t_prompt *prompt, char **word, int *len, int *i)
{
	int	start_index;
	int	end_index;
	char	*substr;
	char	*expanded;
	char	*new_str;
	size_t	before_len;
	size_t	after_len;
	size_t	expanded_len;
	
	start_index = *i;
	end_index = start_index + 1;
	while ((*word)[end_index] && !isspace((*word)[end_index]) && (*word)[end_index] != '$' && (*word)[end_index] != '"' && (*word)[end_index] != '\'')
		end_index++;
	substr = strndup(*word + start_index, end_index - start_index);
	expanded = replace(prompt, substr);
	free(substr);
	if (expanded)
	{
		before_len = start_index;
		after_len = strlen(*word + end_index);
		expanded_len = strlen(expanded);
		new_str = malloc(before_len + expanded_len + after_len + 1);
		if (!new_str) {
			free(expanded);
			return;
		}
		memcpy(new_str, *word, before_len);
		memcpy(new_str + before_len, expanded, expanded_len);
		memcpy(new_str + before_len + expanded_len, *word + end_index, after_len + 1);
		free(*word);
		*word = new_str;
		*len = strlen(*word);
		*i = start_index + expanded_len - 1;
		free(expanded);
	}
}

static bool	process_dollar_sign(char *str, int i, bool sing_quotes)
{
	if (sing_quotes)
		return (false);
	if (ft_isdigit(str[i + 1]))
		return (false);
	if (str[i + 1] == '?')
		return (true);
	if (solo_dollar_sign(str))
		return (false);
	return (true);
}

static bool	has_expandable_vars(char *str)
{
	bool	sing_quotes;
	bool	doub_quotes;
	int		i;

	sing_quotes = false;
	doub_quotes = false;
	i = 0;
	while (str[i])
	{
		if (str[i] == '\'' && (i == 0 || str[i - 1] != '\\') && !doub_quotes)
			sing_quotes = !sing_quotes;
		else if (str[i] == '"' && (i == 0 || str[i - 1] != '\\')
			&& !sing_quotes)
			doub_quotes = !doub_quotes;
		else if (str[i] == '$')
			return (process_dollar_sign(str, i, sing_quotes));
		else if (((str[i] == '<' && str[i + 1] == '<') || (str[i] == '>'
					&& str[i + 1] == '>')) && has_dollar_sign(str, i))
			return (false);
		i++;
	}
	return (true);
}

void	expand_env_vars(t_prompt *prompt, char **str)
{
	int	i;
	int	len; 
	bool	in_single_quote;
	bool	in_double_quote;
	char	current_char;

	in_single_quote = false;
	in_double_quote = false;
	len = strlen(*str);
	i = 0;
	while (i < len)
	{
		current_char = (*str)[i];
		if (current_char == '\'' && !in_double_quote)
			in_single_quote = !in_single_quote;
		else if (current_char == '"' && !in_single_quote)
			in_double_quote = !in_double_quote;
		if (current_char == '$' && !in_single_quote)
		{
			if ((*str)[i + 1] == '?' && has_expandable_vars(*str + i))
				swap_exitmark(prompt, str, &len, &i);
			else if (has_expandable_vars(*str + i) && !solo_dollar_sign(*str + i))
				handle_expandable(prompt, str, &len, &i);
			else if (!has_expandable_vars(*str + i) && isdigit((*str)[i + 1]))
				handle_digit_or_quote(str, &len, &i, true);
			else if (is_quote((*str)[i + 1]) && ((*str)[i + 2]
				&& !is_quote((*str)[i + 2])) && !doll_between_quotes(*str + i))
				handle_digit_or_quote(str, &len, &i, false);
			len = strlen(*str);
		}
		i++;
	}
	if (has_expandable_vars(*str) && dollar_question(*str))
		prompt->exit_codes[prompt->flag3++] = 1;
}
