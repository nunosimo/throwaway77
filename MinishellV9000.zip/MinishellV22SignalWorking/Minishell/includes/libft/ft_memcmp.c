/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:07:42 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:07:42 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_memcmp(const void *str1, const void *str2, size_t n)
{
	char	*s1;
	char	*s2;
	size_t	i;

	s1 = (char *)str1;
	s2 = (char *)str2;
	i = 0;
	while (i < n)
	{
		if (s1[i] != s2[i])
			return ((unsigned char)s1[i] - (unsigned char)s2[i]);
		i++;
	}
	return (0);
}

/* #include <stdio.h>
#include <string.h>
int main ()
{
	char str1[15] = "abbd";
	char str2[15] = "abcd";
	size_t num = 2;
	int res = ft_memcmp(str1, str2, num);

	if(res < 0) {
		printf("str1 comes before str2");
	} else if(res > 0) {
		printf("str2 comes before str1");
	} else {
		printf("str1 is equal to str2");
	}
	
	return(0);
} */