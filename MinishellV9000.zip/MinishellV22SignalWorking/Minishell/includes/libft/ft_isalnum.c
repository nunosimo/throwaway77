/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:06:12 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:06:12 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isalnum(int c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
		|| (c >= '0' && c <= '9'))
		return (1);
	return (0);
}

/*
#include <stdio.h>
int main()
{
    char str[] = "12a-bc.12.,";
    int count = 0;
 
    for (int i = 0; str[i] != '\0'; i++) 
        if (ft_isalnum(str[i]) != 0)
		count++;
    printf("Count = %d", count);
}
*/
