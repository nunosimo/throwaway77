/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:07:21 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:07:21 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
	t_list	*new_list;
	t_list	*node;

	if (!f || !lst)
		return (NULL);
	new_list = NULL;
	while (lst)
	{
		node = ft_lstnew(f(lst->content));
		if (!node)
		{
			ft_lstclear(&node, (*del));
			return (NULL);
		}
		ft_lstadd_back(&new_list, node);
		lst = lst->next;
	}
	return (new_list);
}

/* #include <stdio.h>

void delete_int(void *data) {
    if (data != NULL) {
        free(data);
    }
}

void print_int_data(void *data) {
    if (data != NULL) {
        int *int_ptr = (int *)data;
        printf("%d\n", *int_ptr);
    }
}

void *square_data(void *data) {
    int *original = (int *)data;
    int *result = (int *)malloc(sizeof(int));

    if (original && result) {
        *result = (*original) * (*original);
        return result;
    }

    return NULL;
}

int main()
{
	// Create a list with some integers
	t_list *my_list = NULL;
	int *num1 = (int *)malloc(sizeof(int));
	int *num2 = (int *)malloc(sizeof(int));
	int *num3 = (int *)malloc(sizeof(int));
	int *num4 = (int *)malloc(sizeof(int));
	*num1 = 10;
	*num2 = 20;
	*num3 = 30;
	*num4 = 40;

	// Test ft_lstnew ft_lstaddback ft_lstaddfront
	my_list = ft_lstnew(num1);
	ft_lstadd_back(&my_list, ft_lstnew(num2));
	ft_lstadd_front(&my_list, ft_lstnew(num3));
	t_list *fourth = ft_lstnew(num4);
	ft_lstadd_back(&my_list, fourth);

	// Test ft_lstiter
	ft_lstiter(my_list, print_int_data);
	
	// Test ft_lstsize ft_lstlast
	printf("List size: %d\n", ft_lstsize(my_list));
	t_list *last = ft_lstlast(my_list);
	printf("Last item: %d\n", *((int *)last->content));

	// Test ft_delone
	if (fourth == my_list)
    		my_list = fourth->next;
	else {
    		t_list *prev = my_list;
    		while (prev->next != fourth) {
        	prev = prev->next;
   	}
    	prev->next = fourth->next;
	ft_lstdelone(fourth, delete_int);
	ft_lstiter(my_list, print_int_data);
	}
	
	//Test ft_lstmap
	t_list *new_list =  ft_lstmap(my_list, square_data, delete_int);
	ft_lstiter(new_list, print_int_data);

	// Test ft_lstclear
	ft_lstclear(&my_list, delete_int);
	ft_lstiter(my_list, print_int_data);

	
    return 0;
} */