/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:06:06 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:06:06 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t nelem, size_t size)
{
	void	*ptr;

	if (nelem == 0 || size == 0)
	{
		nelem = 1;
		size = 1;
	}
	ptr = malloc(nelem * size);
	if (!ptr)
		return (NULL);
	ft_bzero(ptr, nelem * size);
	return (ptr);
}

/* #include <stdio.h>
#include <stdlib.h>
int main()
{
    int *arr1 = (int *)ft_calloc(5, sizeof(int));
    for (int i = 0; i < 5; i++) {
        printf("arr1[%d] = %d\n", i, arr1[i]);
    }
    free(arr1);

    int *arr2 = (int *)ft_calloc(0, sizeof(int));
    printf("arr2: %p\n", (void *)arr2);
    free(arr2);

    char *str = (char *)ft_calloc(10, sizeof(char));
    printf("str: %s\n", str);
    free(str);

    return 0;
} */
