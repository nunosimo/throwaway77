/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:06:37 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:06:37 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_isprint(int c)
{
	if (c >= 32 && c < 127)
		return (1);
	return (0);
}

/*
#include <stdio.h>
int main()
{
    char str[] = "123\n\t45";
    int count = 0;
 
    for (int i = 0; str[i] != '\0'; i++) 
        if (ft_isprint(str[i]) != 0)
		count++;
    printf("Count = %d", count);
}
*/