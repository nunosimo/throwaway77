/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:10:37 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:10:37 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_strncmp(const char *str1, const char *str2, size_t n)
{
	size_t	i;

	i = 0;
	while ((str1[i] != '\0' || str2[i] != '\0') && i < n)
	{
		if (str1[i] != str2[i])
			return (((unsigned char)str1[i] - (unsigned char)str2[i]));
		i++;
	}
	return (0);
}

/* int	ft_strncmp(const char *str1, const char *str2, size_t n)
{
	while (*str1 && *str1 == *str2 && n > 0)
	{
		str1++;
		str2++;
		n--;
	}
	if (n == 0)
		return (0);
	return (*(unsigned char *)str1 - *(unsigned char *)str2);
} */

/* #include <stdio.h>
#include <string.h>
int main ()
{
	char str1[15] = "abbd";
	char str2[15] = "abcd";
	size_t num = 3;
	int res = ft_strncmp(str1, str2, num);

	if(res < 0) {
		printf("str1 comes before str2");
	} else if(res > 0) {
		printf("str2 comes before str1");
	} else {
		printf("str1 is equal to str2");
	}
	
	return(0);
} */