/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:06:01 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:06:01 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_bzero(void *s, size_t n)
{
	ft_memset(s, 0, n);
}

/*
#include <stdio.h>
int main ()
{
	char str[] = "This is just a sample string";
	puts(str);
	
	ft_bzero(str+4, 4);
	puts(str);
	
	ft_bzero(str, sizeof(str));
	puts(str);
	
	return(0);
}
*/