/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:10:42 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:10:42 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *str, const char *to_find, size_t n)
{
	size_t	i;
	size_t	j;

	if (!str && !n)
		return (0);
	if (to_find[0] == '\0' || to_find == str)
		return ((char *)str);
	i = 0;
	while (str[i])
	{
		j = 0;
		while (str[i + j] == to_find[j] && (i + j) < n)
		{
			if (str[i + j] == '\0' && to_find[j] == '\0')
				return ((char *)&str[i]);
			j++;
		}
		if (to_find[j] == '\0')
			return ((char *)(str + i));
		i++;
	}
	return (0);
}

/* #include <stdio.h>
#include <string.h>
int main()
{
    const char *haystack = "Hello, World!";
    const char *needle1 = "World";
    const char *needle2 = "Universe";
    const char *empty_needle = "";
    char *result;

    result = ft_strnstr(haystack, needle1, strlen(haystack));
    printf("Test 1: %s\n", result);

    result = ft_strnstr(haystack, needle2, strlen(haystack));
    printf("Test 2: %s\n", result);

    result = ft_strnstr(haystack, empty_needle, strlen(haystack));
    printf("Test 3: %s\n", result);

    result = ft_strnstr(haystack, needle1, 5);
    printf("Test 4: %s\n", result);

    result = ft_strnstr("World!", needle1, 5);
    printf("Test 5: %s\n", result);

    return 0;
}
 */