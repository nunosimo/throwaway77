/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:10:31 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:10:31 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	unsigned int	i;
	char			*new;

	new = (char *)malloc(sizeof(char) * (ft_strlen(s) + 1));
	if (!new)
		return (NULL);
	i = 0;
	while (s[i])
	{
		new[i] = (*f)(i, s[i]);
		i++;
	}
	new[i] = '\0';
	return (new);
}

/* static char sample_function(unsigned int index, char c)
{
    return c + index;
}

#include <stdio.h>
int main()
{
    const char *str1 = "Hello";
    char *result1 = ft_strmapi(str1, &sample_function);
    printf("Test 1: Result of applying my_function 
    to '%s': '%s'\n", str1, result1);
    free(result1);

    const char *str2 = "abc";
    char *result2 = ft_strmapi(str2, &sample_function);
    printf("Test 2: Result of applying my_function 
    to '%s': '%s'\n", str2, result2);
    free(result2);

    const char *str3 = "";
    char *result3 = ft_strmapi(str3, &sample_function);
    printf("Test 3: Result of applying my_function 
    to an empty string: '%s'\n", result3);
    free(result3);

    return 0;
} */