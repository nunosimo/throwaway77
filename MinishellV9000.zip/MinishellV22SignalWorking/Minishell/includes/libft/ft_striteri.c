/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:10:06 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:10:06 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_striteri(char *s, void (*f)(unsigned int, char*))
{
	unsigned int	i;

	i = 0;
	while (s[i])
	{
		f(i, &s[i]);
		i++;
	}
}

/* void sample_function(unsigned int index, char *c)
{
    if (*c >= 'a' && *c <= 'z')
        *c -= 32;
}

#include <stdio.h>
int main()
{
    char str1[] = "Hello";
    ft_striteri(str1, &sample_function);
    printf("Test 1: Result after applying my_function: '%s'\n", str1);

    char str2[] = "";
    ft_striteri(str2, &sample_function);
    printf("Test 3: Result after applying my_function
    to an empty string: '%s'\n", str2);

    return 0;
} */