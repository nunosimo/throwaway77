/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:07:56 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:07:56 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *str, int c, size_t n)
{
	size_t		i;
	char		*copy;

	copy = (char *)str;
	i = 0;
	while (i < n)
	{
		copy[i] = c;
		i++;
	}
	return (str);
}

/*
#include <stdio.h>
int main ()
{
	char str[] = "This is just a sample string";
	puts(str);
	
	ft_memset(str,'$',7);
	puts(str);
	
	return(0);
}
*/