/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:09:44 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:09:44 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putnbr_fd(int n, int fd)
{
	if (n == -2147483648)
	{
		ft_putstr_fd("-2147483648", fd);
		return ;
	}
	if (n < 0)
	{
		n *= -1;
		ft_putchar_fd('-', fd);
	}
	if (n > 9)
	{
		ft_putnbr_fd(n / 10, fd);
	}
	ft_putchar_fd(n % 10 + '0', fd);
}

/* #include <fcntl.h>
int main()
{
    char *filename = "output.txt";
    int number = -2147483648;

    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);

    ft_putnbr_fd(number, fd);

    close(fd);

    return 0;
} */