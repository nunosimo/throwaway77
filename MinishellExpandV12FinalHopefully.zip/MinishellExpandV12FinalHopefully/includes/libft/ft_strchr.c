/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:09:58 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:09:58 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *str, int c)
{
	while (*str && *str != (char)c)
		str++;
	if ((char)c == *str)
		return ((char *)str);
	return (NULL);
}

/* #include <stdio.h>
int main ()
{
   const char str[] = "this .is some.thing here";
   const char ch = '.';
   char *res_ptr = ft_strchr(str, ch);

   printf("String after %c is: %s\n", ch, res_ptr);
   
   return(0);
} */