/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putendl_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:09:40 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:09:40 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putendl_fd(char *s, int fd)
{
	ft_putstr_fd(s, fd);
	ft_putchar_fd('\n', fd);
}

/* #include <fcntl.h>
int main()
{
    char *filename = "output.txt";
    char *text = "Hello, World!";

    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);

    ft_putendl_fd(text, fd);

    close(fd);

    return 0;
} */