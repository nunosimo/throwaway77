/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:10:11 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:10:11 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *str1, char const *str2)
{
	int		i;
	int		j;
	char	*new;

	if (str1 == NULL || str2 == NULL)
		return (NULL);
	new = malloc(sizeof(char) * (ft_strlen(str1) + ft_strlen(str2) + 1));
	if (new == NULL)
		return (NULL);
	i = 0;
	while (str1[i])
	{
		new[i] = str1[i];
		i++;
	}
	j = 0;
	while (str2[j])
	{
		new[i + j] = str2[j];
		j++;
	}
	new[i + j] = '\0';
	return (new);
}

/* #include <stdio.h>

int main()
{
    const char *str1 = "Hello, ";
    const char *str2 = "World!";
    char *result1 = ft_strjoin(str1, str2);
    printf("Test 1: Concatenation of '%s' and '%s':
     '%s'\n", str1, str2, result1);
    free(result1);

    const char *str3 = "";
    const char *str4 = "World!";
    char *result2 = ft_strjoin(str3, str4);
    printf("Test 2: Concatenation of '%s' and '%s':
     '%s'\n", str3, str4, result2);
    free(result2);

    const char *str5 = NULL;
    const char *str6 = "Test";
    char *result3 = ft_strjoin(str5, str6);
    printf("Test 3: Concatenation of NULL and '%s':
     '%s'\n", str6, result3);
    free(result3);

    return 0;
} */
