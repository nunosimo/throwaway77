/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:09:49 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:09:49 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putstr_fd(char *s, int fd)
{
	write(fd, s, ft_strlen(s));
}

/* #include <fcntl.h>
int main()
{
    char *filename = "output.txt";
    char *text = "Hello, World!\n";

    int fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);

    ft_putstr_fd(text, fd);

    close(fd);

    return 0;
} */