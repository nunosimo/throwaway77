/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.co>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/17 12:10:15 by nsimao-f          #+#    #+#             */
/*   Updated: 2023/10/17 12:10:15 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dest, const char *src, size_t size)
{
	size_t	i;
	size_t	j;
	size_t	dlen;
	size_t	slen;

	i = 0;
	j = 0;
	while (dest[j])
		j++;
	dlen = j;
	slen = ft_strlen(src);
	if (size == 0 || size <= dlen)
		return (size + slen);
	while (src[i] && i < size - dlen - 1)
	{
		dest[j] = src[i];
		i++;
		j++;
	}
	dest[j] = '\0';
	return (dlen + slen);
}

/* #include <stdio.h>
int main()
{
    char dest[20] = "Hello, ";
    const char *src = "World!";
//     size_t result = ft_strlcat(dest, src, sizeof(dest));
    size_t result = ft_strlcat(dest, src, 12);

    printf("Concatenated: %s\n", dest);
    printf("Total length of concatenated string: %zu\n", result);

    return 0;
} */