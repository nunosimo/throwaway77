/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nsimao-f <nsimao-f@student.42porto.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/30 12:07:18 by nsimao-f          #+#    #+#             */
/*   Updated: 2024/08/02 19:57:52 by nsimao-f         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

int	g_exitcode;

int	main(int argc, char **argv, char **env)
{
	t_prompt	*prompt;

	if (argc > 1)
	{
		printf("Please don't use arguments!\n");
		exit(1);
	}
	prompt = init_prompt(argv, env);
	set_signal_handlers(SIG_DEFAULT);
	run_shell_loop(prompt, argv, env);
	return (0);
}
